import os
import datetime
import json

books = {
    "Python Programming": 5,
    "Data Structures": 3,
    "Machine Learning": 2
}

lend_records_file = "lend_records.json"

def load_lend_records():
    if os.path.exists(lend_records_file):
        with open(lend_records_file, "r") as file:
            return json.load(file)
    return {}

def save_lend_records(records):
    with open(lend_records_file, "w") as file:
        json.dump(records, file, indent=4)


def lend_book():
    print("\n--- Lend a Book ---")
    book_title = input("Enter the book title: ")
    if book_title not in books:
        print("Book not found in the library.")
        return

    if books[book_title] <= 0:
        print("There are not enough books available to lend.")
        return

    borrower_name = input("Enter borrower's name: ")
    phone_number = input("Enter borrower's phone number: ")
    return_date = (datetime.datetime.now() + datetime.timedelta(days=14)).strftime("%Y-%m-%d")

    lend_records = load_lend_records()
    lend_records[book_title] = {
        "borrower_name": borrower_name,
        "phone_number": phone_number,
        "return_date": return_date
    }
    save_lend_records(lend_records)

    books[book_title] -= 1

    print(f"Book '{book_title}' has been lent to {borrower_name}. Return date is {return_date}.")

def return_book():
    print("\n--- Return a Book ---")
    book_title = input("Enter the book title: ")

    lend_records = load_lend_records()

    if book_title not in lend_records:
        print("No record found for this book being lent.")
        return


    del lend_records[book_title]
    save_lend_records(lend_records)


    books[book_title] += 1

    print(f"Book '{book_title}' has been successfully returned.")

def view_books():
    print("\n--- Available Books ---")
    for title, quantity in books.items():
        print(f"{title}: {quantity} copies")

def main():
    while True:
        print("\n--- Library Management ---")
        print("1. View Books")
        print("2. Lend Book")
        print("3. Return Book")
        print("4. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            view_books()
        elif choice == "2":
            lend_book()
        elif choice == "3":
            return_book()
        elif choice == "4":
            print("Exiting the program. Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
